import React from 'react'

const Playlist = () => {
  return (
    <div>Playlist</div>
  )
}

export default Playlist